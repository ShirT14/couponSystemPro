select * from customers_vs_coupons;
select * from categories;
select * from customers;
select *from companies;




