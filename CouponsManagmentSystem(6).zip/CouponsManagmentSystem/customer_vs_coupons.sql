select * from customers_vs_coupons;
