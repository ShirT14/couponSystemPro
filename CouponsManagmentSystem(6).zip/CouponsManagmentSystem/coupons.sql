select * from coupons;
