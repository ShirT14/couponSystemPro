package com.coupons.sys.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.coupons.sys.beans.Category;
import com.coupons.sys.beans.Coupon;
import com.coupons.sys.beans.Customer;
import com.coupons.sys.exeptions.CouponsSystemException;

public class CustomerVsCouponDBDAO implements CustomerVsCouponDAO {

	public CustomerVsCouponDBDAO() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void deleteCoupon(int couponId) throws CouponsSystemException {

		Connection con = ConnectionPool.getInstance().getConnection();
		try {

			String sqlDeleteCoupon = "delete from customers_vs_coupons where Coupon_ID= ?";
			PreparedStatement pstmt = con.prepareStatement(sqlDeleteCoupon);
			pstmt.setInt(1, couponId);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("Failed to Delete Coupon");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}

	}

	@Override
	public void deleteCustomer(int customerId) throws CouponsSystemException {

		Connection con = ConnectionPool.getInstance().getConnection();
		String sqlDeleteCustomer = "delete from customers_vs_coupons where customer_Id=?";

		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement(sqlDeleteCustomer);
			pstmt.setInt(1, customerId);
			pstmt.executeUpdate();
		} catch (SQLException e) {

			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("failed delete the customer");

		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}

	}

	@Override
	public void addCustomerAndCoupon(Customer customer, Coupon coupon) throws CouponsSystemException {
		// customer.getCoupons().add(coupon);

		Connection con = ConnectionPool.getInstance().getConnection();
		String sqlAdd = "insert into customers_vs_coupons (customer_ID ,  coupon_ID )values (?,?)";
		PreparedStatement pstmt;
		try {
			Statement stmt = con.createStatement();
			stmt.executeLargeUpdate("SET FOREIGN_KEY_CHECKS=0");

			pstmt = con.prepareStatement(sqlAdd);
			pstmt.setInt(1, customer.getId());
			pstmt.setInt(2, coupon.getId());
			pstmt.executeUpdate();
			stmt.executeLargeUpdate("SET FOREIGN_KEY_CHECKS=1");
		} catch (SQLException e) {

			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("faild add customer/company");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}
	}

	public List<Coupon> getAllCustomerCouponsByCategory(int customerId, Category category)
			throws CouponsSystemException {
		String sqlGetCompanyCouponsByCategory = "select * from customer_vs_coupon where customer_id=" + customerId
				+ "and Category_id=" + category;
		return CouponGenericGetter(sqlGetCompanyCouponsByCategory);
	}

	@Override
	public ArrayList<Coupon> getAllCustomerCouponsByMaxPrice(int customerId, Double MaxPrice)
			throws CouponsSystemException {
		String sqlGetAllCompanyCouponsByMaxPrice = "select * from customers_vs_coupons where customer_id=" + customerId
				+ "and Price<" + MaxPrice;
		Connection con = ConnectionPool.getInstance().getConnection();

		try {
			ArrayList<Integer> couponsIdByMaxPrice = new ArrayList<>();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlGetAllCompanyCouponsByMaxPrice);
			Coupon coupon = new Coupon();
			while (rs.next()) {
				couponsIdByMaxPrice.add((rs.getInt("id")));

			}
			ArrayList<Coupon> couponsByMaxPrice = new ArrayList<>();
			for (Integer id : couponsIdByMaxPrice) {
				couponsByMaxPrice.add(new CouponDBDAO().getCoupon(id));
			}
			return couponsByMaxPrice;

		} catch (SQLException e) {
			throw new CouponsSystemException("Faile to get all Coupons");
		} finally {

			ConnectionPool.getInstance().restoreConnection(con);
		}

	}

	public ArrayList<Coupon> CouponGenericGetter(String sql) throws CouponsSystemException {
		ArrayList<Coupon> genericCoupons = new ArrayList<Coupon>();
		String sqlCommand = sql;
		Connection con = ConnectionPool.getInstance().getConnection();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlCommand);

			while (rs.next()) {
				Coupon coupon = new Coupon();
				coupon.setId(rs.getInt("coupon_id"));
				genericCoupons.add(coupon);
			}

		}

		catch (SQLException e) {

			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("Faile to get all Coupons");
		} finally {

			ConnectionPool.getInstance().restoreConnection(con);
		}
		return genericCoupons;

	}

	@Override
	public ArrayList<Customer> getAllCustomersByCouponId(int couponId) throws CouponsSystemException {
		String sql = "select * from customers_vs_coupons where coupon_Id=?";
		List<Integer> allCustomersIdByCoupon = new ArrayList<>();
		Connection con = ConnectionPool.getInstance().getConnection();
		PreparedStatement stmt;
		try {
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, couponId);

			ResultSet rs = stmt.executeQuery();
			if (!rs.next()) {
				return null;
			}
			while (rs.next()) {
				allCustomersIdByCoupon.add(rs.getInt("customer_id"));

			}

		} catch (SQLException e) {

			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("fail get all customers");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}
		ArrayList<Customer> allCustomersByCoupon = new ArrayList<>();
		Customer customer = new Customer();
		CustomersDAO customerDAO = new CustomersDBDAO();
		for (Integer customerId : allCustomersIdByCoupon) {
			customer = customerDAO.getOneCustomer(customerId);
			allCustomersByCoupon.add(customer);

		}

		return allCustomersByCoupon;
	}

}
