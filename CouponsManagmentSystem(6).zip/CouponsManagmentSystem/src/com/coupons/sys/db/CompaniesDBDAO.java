package com.coupons.sys.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.coupons.sys.beans.Company;
import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * the class companiesDBDO is a data access object that responsible to use data
 * from the tables that relate to the company data.
 * 
 * @author Shir
 *
 */
public class CompaniesDBDAO extends CreateTables implements CompaniesDAO {

	@Override
	public boolean isExists(String email, String password) throws CouponsSystemException {
		Connection con;
		con = ConnectionPool.getInstance().getConnection();
		try {
			String sqlIsExists = "select * from companies where email ='" + email + " ' and password=' " + password
					+ "'";
			java.sql.Statement stmt;
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlIsExists);
			if (rs != null) {
				ConnectionPool.getInstance().restoreConnection(con);
				return true;
			}

		} catch (SQLException e) {
			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("Company does't Exist");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}
		return false;

	}

	@Override
	public void addCompany(Company company) throws CouponsSystemException {
		Connection con = ConnectionPool.getInstance().getConnection();
		try {
			String sqlAddCompany = "INSERT INTO companies (name, email, password) VALUES(?, ?, ?)";

			PreparedStatement pstmt = con.prepareStatement(sqlAddCompany);

			pstmt.setString(1, company.getName());
			pstmt.setString(2, company.getEmail());
			pstmt.setString(3, company.getPassword());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			ConnectionPool.getInstance().restoreConnection(con);

			throw new CouponsSystemException("Failed to Add Company");

		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}
	}

	@Override
	public void updateCompany(Company company) throws CouponsSystemException {
		if (!isExists(company.getEmail(), company.getPassword())) {
			throw new CouponsSystemException("the company doesn't exists");
		} else {
			Connection con = ConnectionPool.getInstance().getConnection();
			try {
				String sqlUpdateCompany = "update companies set email=?, password=? where id=?";

				PreparedStatement pstmt = con.prepareStatement(sqlUpdateCompany);

				pstmt.setString(1, company.getEmail());
				pstmt.setString(2, company.getPassword());
				pstmt.setInt(3, company.getId());

				pstmt.executeUpdate();
			} catch (SQLException e) {

				ConnectionPool.getInstance().restoreConnection(con);
				throw new CouponsSystemException("Failed to update Company");
			} finally {
				ConnectionPool.getInstance().restoreConnection(con);

			}
		}

	}

	@Override
	public void deleteCompany(int companyID) throws CouponsSystemException {
		Company company = getCompany(companyID);
		if (!isExists(company.getEmail(), company.getPassword())) {
			throw new CouponsSystemException("the company doesn't exists");
		} else {
			Connection con = ConnectionPool.getInstance().getConnection();
			try {

				String sqlDeleteCompany = "delete from companies where id= " + companyID;
				Statement stmt = con.createStatement();
				stmt.executeUpdate(sqlDeleteCompany);
			} catch (SQLException e) {
				ConnectionPool.getInstance().restoreConnection(con);

				throw new CouponsSystemException("Failed To Delete Company");
			} finally {
				ConnectionPool.getInstance().restoreConnection(con);

			}
		}
	}

	@Override
	public ArrayList<Company> getAllCompanies() throws CouponsSystemException {
		// TODO Auto-generated method stub
		ArrayList<Company> allCompanies = new ArrayList<Company>();
		String sqlGetAllCompanies = "select * from companies";

		Connection con = ConnectionPool.getInstance().getConnection();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlGetAllCompanies);

			while (rs.next()) {
				Company company = new Company();
				company.setId(rs.getInt("id"));
				company.setEmail(rs.getString("email"));
				company.setName(rs.getString("name"));
				company.setPassword(rs.getString("password"));

				allCompanies.add(company);

			}

		} catch (SQLException e) {
			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("Failed To get all the Companies");

		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}

		return allCompanies;
	}

	@Override
	public Company getCompany(int companyID) throws CouponsSystemException {

		Company company = new Company();

		Connection con = ConnectionPool.getInstance().getConnection();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from companies where id=" + companyID);
			CompaniesDBDAO compDAO = new CompaniesDBDAO();

			while (rs.next()) {
				company.setId(rs.getInt("id"));
				company.setEmail(rs.getString("email"));
				company.setName(rs.getString("name"));
				company.setPassword(rs.getString("password"));
			}
			if (isExists(company.getEmail(), company.getPassword())) {
				ConnectionPool.getInstance().restoreConnection(con);
				return company;
			} else {
				ConnectionPool.getInstance().restoreConnection(con);
				throw new CouponsSystemException("the compant doesn't exsist ");
			}

		} catch (SQLException | NullPointerException e) {
			ConnectionPool.getInstance().restoreConnection(con);

			throw new CouponsSystemException("Failed to get Company");

		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}

	}

	@Override
	public Company getCompany(String email) throws CouponsSystemException {

		Company company = new Company();
		Connection con = ConnectionPool.getInstance().getConnection();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from companies where email= '" + email + "'");

			while (rs.next()) {
				company.setId(rs.getInt("id"));
				company.setEmail(rs.getString("email"));
				company.setName(rs.getString("name"));
				company.setPassword(rs.getString("password"));
			}

		} catch (SQLException | NullPointerException e) {
			ConnectionPool.getInstance().restoreConnection(con);

			throw new CouponsSystemException("Failed to get Company");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}
		return company;

	}

}
