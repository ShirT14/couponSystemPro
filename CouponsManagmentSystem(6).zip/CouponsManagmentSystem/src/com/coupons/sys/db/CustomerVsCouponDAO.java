package com.coupons.sys.db;

import java.util.ArrayList;

import com.coupons.sys.beans.Coupon;
import com.coupons.sys.beans.Customer;
import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * an interface that allows to make change on the customer_vs_coupon table
 * 
 * @author Shir
 *
 */
public interface CustomerVsCouponDAO {
	/**
	 * delete coupon from the table
	 * 
	 * @param couponId
	 * @throws CouponsSystemException
	 */
	public void deleteCoupon(int couponId) throws CouponsSystemException;

	/**
	 * Delete customer from the table.
	 * 
	 * @param CustomerId
	 * @throws CouponsSystemException
	 */
	public void deleteCustomer(int CustomerId) throws CouponsSystemException;

	/**
	 * add customer and a coupon to the table
	 * 
	 * @param customer
	 * @param coupon
	 * @throws CouponsSystemException
	 */
	public void addCustomerAndCoupon(Customer customer, Coupon coupon) throws CouponsSystemException;

	/**
	 * returns all the coupons of one customer by maximum price
	 * 
	 * @param customerId
	 * @param MaxPrice
	 * @return AllCustomerCouponsByMaxPrice
	 * @throws CouponsSystemException
	 */

	ArrayList<Coupon> getAllCustomerCouponsByMaxPrice(int customerId, Double MaxPrice) throws CouponsSystemException;

	/***
	 * a method that return a list of coupon by demand.
	 * 
	 * @param sql
	 * @return
	 * @throws CouponsSystemException
	 */
	public ArrayList<Coupon> CouponGenericGetter(String sql) throws CouponsSystemException;

	/***
	 * returns all coupons of one customer by coupon's id.
	 * 
	 * @param couponId
	 * @return AllCustomersByCouponId
	 * @throws CouponsSystemException
	 */
	public ArrayList<Customer> getAllCustomersByCouponId(int couponId) throws CouponsSystemException;

}
