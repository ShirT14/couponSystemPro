package com.coupons.sys.db;

import java.util.ArrayList;

import com.coupons.sys.beans.Company;
import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * an interface that allows to make change in companies table.
 * 
 * @author Shir
 *
 */
public interface CompaniesDAO {
	/**
	 * the method isExist check if the company is exists in the database according
	 * to the email and the password.
	 * 
	 * @param email
	 * @param password
	 * @return true/false
	 * @throws CouponsSystemException
	 */
	public boolean isExists(String email, String password) throws CouponsSystemException;

	/**
	 * addCompany is a method that allows to add a company to the database.
	 * 
	 * @param company
	 * @throws CouponsSystemException
	 */
	public void addCompany(Company company) throws CouponsSystemException;

	/**
	 * updateCompany is a method who allows to update company from the company table
	 * from the database.
	 * 
	 * @param company
	 * @throws CouponsSystemException
	 */
	public void updateCompany(Company company) throws CouponsSystemException;

	/**
	 * deleteCompany is a method that allows to delete a company according a
	 * company's id number.
	 * 
	 * @param companyID
	 * @throws CouponsSystemException
	 */
	public void deleteCompany(int companyID) throws CouponsSystemException;

	/**
	 * getAllCompany is a method that can be use to get all the companies from the
	 * database. the method gets no parameters.
	 * 
	 * @return company
	 * @throws CouponsSystemException
	 */

	public ArrayList<Company> getAllCompanies() throws CouponsSystemException;

	/**
	 * the method getCompny allows to get specified company according to a company's
	 * id number.
	 * 
	 * @param companyID
	 * @return company
	 * @throws CouponsSystemException
	 */

	public Company getCompany(int companyID) throws CouponsSystemException;

	/**
	 * the method getCompny allows to get specified company according to a company's
	 * email.
	 * 
	 * @param email
	 * @return compny
	 * @throws CouponsSystemException
	 */
	public Company getCompany(String email) throws CouponsSystemException;

}
