package com.coupons.sys.beans;

import java.util.ArrayList;

/**
 * the customer class represent customer, every customer has id, first name,
 * last name, email, password and a list of coupon that the customer has
 * approached.
 * 
 * @author Shir
 *
 */
public class Customer {
	/**
	 * 
	 * @param id
	 * @param firstName
	 * @param lastName
	 * @param email
	 * @param password
	 */
	public Customer(int id, String firstName, String lastName, String email, String password) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
	}

	/**
	 * 
	 * @param firstName
	 * @param lastName
	 * @param email
	 * @param password
	 */
	public Customer(String firstName, String lastName, String email, String password) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
	}

	private int id;
	private String firstName;
	private String lastName;
	private String email;
	private String password;
	private ArrayList<Coupon> coupons;

	/**
	 * 
	 * @param id
	 * @param firstName
	 * @param lastName
	 * @param email
	 * @param password
	 * @param coupons
	 */
	public Customer(int id, String firstName, String lastName, String email, String password,
			ArrayList<Coupon> coupons) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.coupons = coupons;
	}

	/**
	 * 
	 * @param id
	 */
	public Customer(int id) {
		super();
		this.id = id;
	}

	public Customer() {
		super();
	}

	/**
	 * 
	 * @param id
	 * @param firstName
	 * @param lastName
	 */
	public Customer(int id, String firstName, String lastName) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	/**
	 * returns customer's first name.
	 * 
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * sets customer's first name.
	 * 
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * returns customer's last name.
	 * 
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * sets customer's last name.
	 * 
	 * @param lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * returns customer's email.
	 * 
	 * @return email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * sets customer's email.
	 * 
	 * @param email
	 */

	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * returns customer's password.
	 * 
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * sets customer's password
	 * 
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * return's list of all the coupons that the customer a purchased.
	 * 
	 * @return coupons
	 */
	public ArrayList<Coupon> getCoupons() {
		return coupons;
	}

	/**
	 * sets the coupon's list
	 * 
	 * @param coupons
	 */

	public void setCoupons(ArrayList<Coupon> coupons) {
		this.coupons = coupons;
	}

	/**
	 * return's customers Id
	 * 
	 * @return id
	 */
	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", emaile=" + email
				+ ", password=" + password + ", coupons=" + coupons + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (id != other.id)
			return false;
		return true;
	}

	/**
	 * sets the customer's id.
	 * 
	 * @param id
	 */
	public void setId(int id) {
		// TODO Auto-generated method stub
		this.id = id;
	}

}
