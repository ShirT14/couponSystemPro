package com.coupons.sys.clients;

import java.util.ArrayList;

import com.coupons.sys.beans.Company;
import com.coupons.sys.beans.Coupon;
import com.coupons.sys.beans.Customer;
import com.coupons.sys.db.CompaniesDAO;
import com.coupons.sys.db.CompaniesDBDAO;
import com.coupons.sys.db.CouponDAO;
import com.coupons.sys.db.CouponDBDAO;
import com.coupons.sys.db.CustomerVsCouponDAO;
import com.coupons.sys.db.CustomerVsCouponDBDAO;
import com.coupons.sys.db.CustomersDAO;
import com.coupons.sys.db.CustomersDBDAO;
import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * AdminFacade is a class that defined the business logic of administrator
 * client.
 * 
 * @author Shir
 *
 */
public class AdminFacade extends ClientFacade {
	private String password = "admin";
	private String email = "admin@admin.com";
	private CustomersDAO customerDAO = new CustomersDBDAO();
	private CouponDAO couponDAO = new CouponDBDAO();
	private CustomerVsCouponDAO customerVsCoupon = new CustomerVsCouponDBDAO();
	private CompaniesDAO companyDAO = new CompaniesDBDAO();

	public CustomersDAO getCustomerDAO() {
		return this.customerDAO;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AdminFacade other = (AdminFacade) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}

	/**
	 * returns admin's password.
	 * 
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * return's admin's email.
	 * 
	 * @return email
	 */
	public String getEmail() {
		return email;
	}

	public AdminFacade() {
		super();
	}

	@Override
	public boolean login(String emil, String password) {

		return (this.email.equals(emil)) && (this.password.equals(password));

	}

	/**
	 * adds a company to the database.
	 * 
	 * @param newCompany
	 * @throws CouponsSystemException
	 */
	public void addCompany(Company newCompany) throws CouponsSystemException {

		ArrayList<Company> companies = this.companyDAO.getAllCompanies();

		for (Company company : companies) {

			if ((company.getName().equals(newCompany.getName()))
					|| (company.getEmail().equals(newCompany.getEmail()))) {

				throw new CouponsSystemException("there is alredy a company with this name or email please try agine");

			}
		}

		this.companyDAO.addCompany(newCompany);

	}

	/**
	 * updates a company in the database.
	 * 
	 * @param newCompany
	 * @throws CouponsSystemException
	 */
	public void updateCompany(Company newCompany) throws CouponsSystemException {

		this.companyDAO.updateCompany(newCompany);

	}

	/**
	 * deletes company from the database.
	 * 
	 * @param companyId
	 * @throws CouponsSystemException
	 */
	public void deleteCompany(int companyId) throws CouponsSystemException {

		ArrayList<Coupon> allCouponsOfCompany = this.couponDAO.getALLCouponsByCompanyId(companyId);
		for (Coupon coupon : allCouponsOfCompany) {
			this.customerVsCoupon.deleteCoupon(coupon.getId());
			this.couponDAO.deleteCoupon(coupon.getId());

		}

		this.companyDAO.deleteCompany(companyId);
	}

	/**
	 * return's all the coupons of the company.
	 * 
	 * @return allCompanies
	 * @throws CouponsSystemException
	 */

	public ArrayList<Company> getAllCompanies() throws CouponsSystemException {

		ArrayList<Company> allCompanies = this.companyDAO.getAllCompanies();
		return allCompanies;

	}

	/**
	 * return company by company's id.
	 * 
	 * @param companyId
	 * @return company
	 * @throws CouponsSystemException
	 */
	public Company getComapny(int companyId) throws CouponsSystemException {

		Company company = this.companyDAO.getCompany(companyId);
		return company;
	}

	public void addCustomer(Customer newCustomer) throws CouponsSystemException {
		ArrayList<Customer> customers = this.customerDAO.getAllCustomers();
		for (Customer customer : customers) {
			if (customer.getEmail().equals(newCustomer.getEmail())) {

				throw new CouponsSystemException("you can't add a customer if his Email already exist in the system");
			}
		}
		this.customerDAO.addCustomer(newCustomer);
	}

	/**
	 * Updates customer
	 * 
	 * @param newCustomer
	 * @throws CouponsSystemException
	 */
	public void updateCustomer(Customer newCustomer) throws CouponsSystemException {

		this.customerDAO.updateCustomer(newCustomer);

	}

	/**
	 * Deletes one customer by id.
	 * 
	 * @param customerId
	 * @throws CouponsSystemException
	 */
	public void deleteCustomer(int customerId) throws CouponsSystemException {
		this.customerVsCoupon.deleteCustomer(customerId);
		this.customerDAO.deleteCustomer(customerId);

	}

	/**
	 * returns all the customers in the database.
	 * 
	 * @return allCustomers
	 * @throws CouponsSystemException
	 */
	public ArrayList<Customer> getAllCustomers() throws CouponsSystemException {
		ArrayList<Customer> allCustomers = this.customerDAO.getAllCustomers();
		return allCustomers;
	}

	/**
	 * Returns one customer by customer id.
	 * 
	 * @param customerId
	 * @return customer
	 * @throws CouponsSystemException
	 */
	public Customer getOneCustomer(int customerId) throws CouponsSystemException {
		Customer customer = customerDAO.getOneCustomer(customerId);
		return customer;

	}
}
