package com.coupons.sys.clients;

import java.util.List;
import java.util.TimerTask;

import com.coupons.sys.beans.Coupon;
import com.coupons.sys.db.CouponDAO;
import com.coupons.sys.db.CouponDBDAO;
import com.coupons.sys.exeptions.CouponsSystemException;

public class CouponExpirationDailyJob extends TimerTask implements Runnable {

	private CouponDBDAO couponDAO = new CouponDBDAO();
	private boolean quit = false;

	public boolean isQuit() {
		return quit;
	}

	public void setQuit(boolean quit) {
		this.quit = quit;
	}

	public CouponDAO getCouponDAO() {
		return couponDAO;
	}

	public CouponExpirationDailyJob() {
		super();

	}

	@Override
	public void run() {
		if (!isQuit()) {

			try {
				List<Coupon> allCoupons;
				allCoupons = this.couponDAO.getAllExpiredCoupons();
				if (allCoupons.isEmpty()) {
					try {
						completeTask();
					} catch (InterruptedException e) {
						if (quit) {
							return;
						}
					}
				} else {
					for (Coupon coupon : allCoupons) {

						this.couponDAO.deleteCoupon(coupon.getId());

					}
					try {
						completeTask();
					} catch (InterruptedException e) {

						if (quit) {
							return;
						}
					}
				}
			} catch (CouponsSystemException e) {
				try {

					throw new CouponsSystemException("there no coupons in the system");
				} catch (CouponsSystemException e1) {
					// TODO Auto-generated catch block
					System.out.println(e1);
				} finally {
					try {
						completeTask();
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						if (quit) {
							return;
						}
					}

				}

			}

		}

	}

	public void stop() {
		this.quit = true;
	}

	private void completeTask() throws InterruptedException {

		Thread.sleep(8640000);

	}

}
