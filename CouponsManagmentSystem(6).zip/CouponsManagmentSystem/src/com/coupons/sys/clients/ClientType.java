package com.coupons.sys.clients;

public enum ClientType {

	ADMINISTRATOR, COMPANY, CUSTOMER;

}
