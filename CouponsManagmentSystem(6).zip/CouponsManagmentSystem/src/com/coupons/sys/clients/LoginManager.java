package com.coupons.sys.clients;

import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * a singletone class that return client facade according to email, password ,
 * and a clientType.
 * 
 * @author Shir
 *
 */
public class LoginManager {

	private LoginManager() {

		super();

	}

	private static LoginManager instance;

	/**
	 * returns the one object of the class, in case theresn't the method called the
	 * constructor.
	 * 
	 * @return instance.
	 */
	public static LoginManager getInstance() {
		if (instance == null) {
			LoginManager instance = new LoginManager();
			return instance;
		}
		return instance;
	}

	/**
	 * returns ClientFacae according to email,password, and client type.
	 * 
	 * @param email
	 * @param password
	 * @param clientType
	 * @return clientFacade
	 * @throws CouponsSystemException
	 */
	public ClientFacade logIn(String email, String password, ClientType clientType) throws CouponsSystemException {
		switch (clientType) {
		case ADMINISTRATOR:
			AdminFacade admin = new AdminFacade();
			if (admin.login(email, password)) {
				return admin;
			}
			break;

		case COMPANY: {
			CompanyFacade company = new CompanyFacade();
			if (company.login(email, password)) {
				return company;
			}
		}
			break;

		case CUSTOMER:
			CustomerFacade customer = new CustomerFacade();
			if (customer.login(email, password)) {
				return customer;
			}
			break;
		}

		return null;
	}

}
