select * from companies;
