package com.coupons.sys.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * connectionPool is a class that create and send connection to the user in a
 * controlled manner.
 * 
 * @author Shir
 *
 */
public class ConnectionPool {
	private static Set<Connection> connections = new HashSet<>();
	private int maxConnections = 10;
	private boolean isClose = false;
	String url = "jdbc:mysql://127.0.0.1:3306/coupons?useSSL=false";
	String driver = "com.mysql.jdbc.Driver";
	String userName = "shir";
	String password = "12345";

	public boolean isClose() {
		return isClose;
	}

	public int getMaxConnections() {
		return maxConnections;
	}

	public static Set<Connection> getConnections() {
		return connections;
	}

	public String getUrl() {
		return url;
	}

	// private String url = "jdbc:derby://localhost:1527/CouponsSystemDB";

	private static ConnectionPool instance;

	public static ConnectionPool getInstance() throws CouponsSystemException {
		if (instance == null) {
			instance = new ConnectionPool();
		}
		return instance;
	}

	private ConnectionPool() throws CouponsSystemException {
		// add 10 connections to the set
		for (int i = 0; i < maxConnections; i++) {
			try {
				connections.add(DriverManager.getConnection(url, userName, password));
				connections.iterator().next();

			} catch (SQLException e) {
				// TODO Auto-generated catch block

				throw new CouponsSystemException("could not create connection ");
			}
		}

	}

	public synchronized Connection getConnection() throws CouponsSystemException {

		while (connections.size() == 0 && !isClose) {

			try {
				wait();
				System.out.println("wait for connection");
			} catch (InterruptedException e) {
				throw new CouponsSystemException("Failed To get Connection");
			}

		}
		Connection availableConnection = ConnectionPool.getConnections().iterator().next();
		getConnections().remove(availableConnection);

		return availableConnection;
	}

	public synchronized void restoreConnection(Connection connection) {
		connections.add(connection);
		notifyAll();

	}

	public synchronized void closeAllConnections() throws InterruptedException, SQLException {
		this.isClose = true;
		while (connections.size() < 10) {

			wait();

		}

		notifyAll();
		for (int i = 0; i < maxConnections; i++) {

			connections.iterator().next().close();

		}

	}
}
