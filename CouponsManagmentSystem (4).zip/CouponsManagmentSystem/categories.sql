select * from categories;
