select * from customers;
