package com.coupons.sys.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * a class that converts string to sql date.
 * 
 * @author Shir
 *
 */
public class DateConvert {

	public DateConvert() {

	}

	/**
	 * a static method that convert string to sql date.
	 * 
	 * @param dateInString
	 * @return sqlDate
	 * @throws CouponsSystemException
	 */
	public static java.sql.Date stringToDate(String dateInString) throws CouponsSystemException {
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
		try {

			Date parsed = sdf1.parse(dateInString);
			java.sql.Date sqlDate = new java.sql.Date(parsed.getTime());
			return sqlDate;
		} catch (ParseException e) {

			throw new CouponsSystemException("Faile to Parse Date");

		}
	}
}
