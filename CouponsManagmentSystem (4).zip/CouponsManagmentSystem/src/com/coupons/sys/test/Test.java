package com.coupons.sys.test;

import java.sql.Date;
import java.sql.SQLException;

import com.coupons.sys.beans.Coupon;
import com.coupons.sys.clients.AdminFacade;
import com.coupons.sys.clients.ClientType;
import com.coupons.sys.clients.CompanyFacade;
import com.coupons.sys.clients.CouponExpirationDailyJob;
import com.coupons.sys.clients.CustomerFacade;
import com.coupons.sys.clients.LoginManager;
import com.coupons.sys.db.ConnectionPool;
import com.coupons.sys.exeptions.CouponsSystemException;

public class Test {

	public static void main(String[] args) {

		try {
			testAll();
		} catch (CouponsSystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

	}

	public Test() {
		// TODO Auto-generated constructor stub
	}

	@SuppressWarnings("deprecation")
	public static void testAll() throws CouponsSystemException {

		ConnectionPool.getInstance();

		CouponExpirationDailyJob job = new CouponExpirationDailyJob();
		Thread threadJob = new Thread(job);
		threadJob.start();
		AdminFacade admin;

		try {
			admin = (AdminFacade) LoginManager.getInstance().logIn("admin@admin.com", "admin",
					ClientType.ADMINISTRATOR);
		} catch (CouponsSystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new CouponsSystemException("couldn't login");
		}

//		admin.addCompany(new Company("Fox", "fox@fox.com", "1234"));
//		admin.addCompany(new Company("Mega", "mega@mega.com", "a1234"));
//		admin.addCompany(new Company("Profit", "profit@pro.com", "1234p"));
//		admin.addCompany(new Company("Bug", "bug@Bug.com", "b1234"));
//		admin.addCompany(new Company("BBB", "BBB@bbb.com", "3b56"));

		CompanyFacade fox = (CompanyFacade) LoginManager.getInstance().logIn("fox@fox.com", "1234", ClientType.COMPANY);
		Date startDate = DateConvert.stringToDate("29-6-2019");
		Date endDate = DateConvert.stringToDate("29-6-2020");
		// fox.addCoupon(new Coupon(10, 6, "vacation discount", "pay and get discount
		// for vacation", startDate, endDate, 5,
		// 250, "imag#"));
		// fox.updateCoupon(new Coupon(108, 10, 6, "vacation discount", "pay and get
		// discount for vacation", startDate,
		// endDate, 6, 300, "image#"));
		System.out.println(fox.getCompanyCoupons());
		CompanyFacade bug = (CompanyFacade) LoginManager.getInstance().logIn("bug@bug.com", "b1234",
				ClientType.COMPANY);
//		bug.addCoupon(new Coupon(13, 4, "1+1", "the cheaper 1", DateConvert.stringToDate("30-6-2019"),
//				DateConvert.stringToDate("1-7-2019"), 3, 10, "im88"));
		bug.updateCoupon(new Coupon(112, 13, 4, "1+1", "the cheaper one", DateConvert.stringToDate("30-06-2019"),
				DateConvert.stringToDate("30-09-2020"), 4, 15, "im88"));
//		bug.addCoupon(new Coupon(13, 4, "2+1", "the cheaper one", DateConvert.stringToDate("30-6-2019"),
//				DateConvert.stringToDate("1-10-2019"), 3, 10, "im81"));
		// admin.deleteCompany(companyId);
		// admin.addCustomer(new Customer("Chris", "Hamsworth", "chrish@mail.com",
		// "12345"));
//		admin.addCustomer(new Customer("Honey", "Goldman", "honey@mail.com", "1234"));
//		admin.addCustomer(new Customer("Ido", "Ashkenazi", "ido@mail.com", "4563"));
		CustomerFacade shir = (CustomerFacade) LoginManager.getInstance().logIn("shir@gmail.com", "2345",
				ClientType.CUSTOMER);
//		shir.purchaseCoupon(new Coupon(112, 13, 4, "1+1", "the cheaper one", DateConvert.stringToDate("30-06-2019"),
//				DateConvert.stringToDate("30-09-2020"), 4, 15, "im88"));
		CustomerFacade chris = (CustomerFacade) LoginManager.getInstance().logIn("chrish@mail.com", "12345",
				ClientType.CUSTOMER);
//		chris.purchaseCoupon(new Coupon(115, 10, 6, "vacation discount", "pay and get discountfor vacation",
//				DateConvert.stringToDate("29-06-2019"), DateConvert.stringToDate("29-06-2020"), 5, 250, "imag#"));

		// admin.deleteCompany(10);
		bug.deleteCoupon(112);
		CompanyFacade bbb = (CompanyFacade) LoginManager.getInstance().logIn("BBB@bbb.com", "3b56", ClientType.COMPANY);
//		bbb.addCoupon(new Coupon(14, 3, "free fries", "free fries with every burger",
//				DateConvert.stringToDate("29-06-2019"), DateConvert.stringToDate("29-06-2020"), 10, 50, "jpg"));
//		bbb.addCoupon(new Coupon(14, 3, "free drink", "free drink with every burger",
//				DateConvert.stringToDate("29-06-2019"), DateConvert.stringToDate("29-06-2020"), 7, 45, "jpg2"));
//		bbb.addCoupon(new Coupon(14, 3, "50% off burger", "50% off of every burger",
//				DateConvert.stringToDate("29-06-2019"), DateConvert.stringToDate("29-06-2020"), 10, 50, "jpg1"));
		CustomerFacade honey = (CustomerFacade) LoginManager.getInstance().logIn("honey@mail.com", "1234",
				ClientType.CUSTOMER);
//		honey.purchaseCoupon(new Coupon(116, 14, 3, "free fries", "free fries with every burger",
//				DateConvert.stringToDate("29-06-2019"), DateConvert.stringToDate("29-06-2020"), 10, 50, "jpg"));
//		honey.purchaseCoupon(new Coupon(113, 13, 4, "2+1", "the cheaper one", DateConvert.stringToDate("30-6-2019"),
//				DateConvert.stringToDate("1-10-2019"), 3, 10, "im81"));
		System.out.println("all coupons" + honey.getAllCustomerCoupons());
		System.out.println("all food coupon that honey boght " + honey.getAllCustomerCoupons(3));
		System.out.println("all honey's coupons under 30 shekels " + honey.getAllCoupon(30));
		System.out.println(admin.getAllCompanies() + "all the companies");
		System.out.println(admin.getAllCustomers() + "all customers");
		System.out.println(admin.getOneCustomer(6));
		System.out.println(admin.getComapny(11));
		System.out.println(bbb.getCompanyCoupons());
		CustomerFacade Ido = (CustomerFacade) LoginManager.getInstance().logIn("ido@mail.com", "4563",
				ClientType.CUSTOMER);
		System.out.println(Ido.getCustomer());
//		bbb.addCoupon(new Coupon(14, 3, "50% drink", "in every buy", startDate, DateConvert.stringToDate("30-06-2019"),
//				3, 20, "##"));

		try {
			ConnectionPool.getInstance().closeAllConnections();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			threadJob.stop();
			threadJob.interrupt();

		}

	}

}