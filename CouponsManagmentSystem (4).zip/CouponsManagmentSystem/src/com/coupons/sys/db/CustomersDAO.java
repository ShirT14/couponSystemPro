package com.coupons.sys.db;

import java.util.ArrayList;

import com.coupons.sys.beans.Customer;
import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * an interface that allows to make change in customers table.
 * 
 * @author Shir
 *
 */
public interface CustomersDAO {
	/**
	 * Check if the customer is exist
	 * 
	 * @param email
	 * @param password
	 * @return true/false
	 * @throws CouponsSystemException
	 */
	public boolean isExists(String email, String password) throws CouponsSystemException;

	/**
	 * add a new customer
	 * 
	 * @param customer
	 * @throws CouponsSystemException
	 */
	public void addCustomer(Customer customer) throws CouponsSystemException;

	/**
	 * update a customer.
	 * 
	 * @param customer
	 * @throws CouponsSystemException
	 */
	public void updateCustomer(Customer customer) throws CouponsSystemException;

	/**
	 * delete a coupon by coupon's id.
	 * 
	 * @param customerID
	 * @throws CouponsSystemException
	 */
	public void deleteCustomer(int customerID) throws CouponsSystemException;

	/**
	 * return a list of all the customer in the database.
	 * 
	 * @return allCusomers
	 * @throws CouponsSystemException
	 */
	public ArrayList<Customer> getAllCustomers() throws CouponsSystemException;

	/**
	 * return on customer from the database by customer's id.
	 * 
	 * @param customerID
	 * @return customer
	 * @throws CouponsSystemException
	 */
	public Customer getOneCustomer(int customerID) throws CouponsSystemException;

	/**
	 * return one customer by customer's email.
	 * 
	 * @param email
	 * @return
	 * @throws CouponsSystemException
	 */
	public Customer getOneCustomer(String email) throws CouponsSystemException;

}
