package com.coupons.sys.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**
		 * create the tables of the database.
		 *
		 */

		// String url = "jdbc:derby://localhost:1527/CouponsSystemDB";
		String url = "jdbc:mysql://127.0.0.1:3306/coupons?useSSL=false";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "shir";
		String password = "12345";

		/**
		 * the creation of the companies table
		 */

		String companiesSQL = "create table COMPANIES (ID INT not null AUTO_INCREMENT,";
		companiesSQL += " NAME varchar(20), EMAIL varchar(20) ,PASSWORD varchar(20), primary key(ID) )";

		try {
			Class.forName(driver).newInstance();
			Connection con = DriverManager.getConnection(url, userName, password);
			Statement stmt = con.createStatement();

			// stmt.executeUpdate(companiesSQL);
			System.out.println(stmt);

		} catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {

			e.printStackTrace();
		}

		/**
		 * create the customers table.
		 */

		String customersSQL = "create table CUSTOMERS (ID INT  not null AUTO_INCREMENT,";
		customersSQL += "FIRST_NAME varchar(20), LAST_NAME varchar(20), EMAIL varchar(20) ,PASSWORD varchar(20), primary key(ID)) ";
		try {
			Class.forName(driver).newInstance();
			Connection con = DriverManager.getConnection(url, userName, password);
			Statement stmt = con.createStatement();

			// stmt.executeUpdate(customersSQL);
			System.out.println(stmt);

		} catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {

			e.printStackTrace();
		}

		/**
		 * create the categories table.
		 */
		String categoriesSQL = "create table CATEGORIES (ID int not null AUTO_INCREMENT";
		categoriesSQL += ",NAME varchar(20),primary key(ID))";
		try {
			Class.forName(driver).newInstance();
			Connection con = DriverManager.getConnection(url, userName, password);
			Statement stmt = con.createStatement();

			// stmt.executeUpdate(categoriesSQL);
//			stmt.executeUpdate("insert into categories (name) values ('food')");
//			stmt.executeUpdate("insert into categories (name) values ('electricity')");
//			stmt.executeUpdate("insert into categories (name) values ('resturant')");
//			stmt.executeUpdate("insert into categories (name) values ('vaction')");
			System.out.println(stmt);

		} catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {

			e.printStackTrace();
		}

		String couponsSQL = "create table COUPONS (ID int not null AUTO_INCREMENT";
		couponsSQL += ",COMPANY_ID integer , CATEGORY_ID integer , TITLE varchar(20), DESCRIPTION varchar(40)";
		couponsSQL += ",START_DATE date, END_DATE DATE, AMOUNT integer, PRICE double, IMAGE varchar(20)";
		couponsSQL += ",primary key (id), FOREIGN KEY (company_id) REFERENCES COMPANIES(id) ,FOREIGN KEY (category_id) REFERENCES CATEGORIES(id))";
		// System.out.println(couponsSQL);
		try {
			Class.forName(driver).newInstance();
			Connection con = DriverManager.getConnection(url, userName, password);
			Statement stmt = con.createStatement();

			// stmt.executeUpdate(couponsSQL);
			System.out.println(stmt);

		} catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {

			e.printStackTrace();
		}
		String couponsVScustomersSQL = "create table CUSTOMERS_VS_COUPONS( customer_id integer , coupon_id integer,foreign key (customer_id) references customers(id), foreign key (coupon_id) references coupons(id))";
		try {
			Class.forName(driver).newInstance();
			Connection con = DriverManager.getConnection(url, userName, password);
			Statement stmt = con.createStatement();

			// stmt.executeUpdate(couponsVScustomersSQL);
			System.out.println(stmt);

		} catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {

			e.printStackTrace();
		}

	}
}
