package com.coupons.sys.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.coupons.sys.beans.Customer;
import com.coupons.sys.exeptions.CouponsSystemException;

public class CustomersDBDAO implements CustomersDAO {

	public CustomersDBDAO() {
		// TODO Auto-generated constructor stub
		super();
	}

	@Override
	public boolean isExists(String email, String password) throws CouponsSystemException {
		// TODO Auto-generated method stub
		String sqlIsExists = "select * from customers where email= ? and password=?";

		Connection con = ConnectionPool.getInstance().getConnection();
		try {
			java.sql.PreparedStatement stmt = con.prepareStatement(sqlIsExists);
			stmt.setString(1, email);
			stmt.setString(2, password);

			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				ConnectionPool.getInstance().restoreConnection(con);
				return true;
			} else
				return false;
		} catch (SQLException e) {

			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("Company Not Found");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}
	}

	@Override
	public void addCustomer(Customer customer) throws CouponsSystemException {
		// TODO Auto-generated method stub
		Connection con = ConnectionPool.getInstance().getConnection();
		String sqlAddCustomer = "insert into customers (first_Name, last_Name, email, password) values (?,?,?,?)";

		try {
			PreparedStatement pstmt = con.prepareStatement(sqlAddCustomer);

			pstmt.setString(1, customer.getFirstName());
			pstmt.setString(2, customer.getLastName());
			pstmt.setString(3, customer.getEmail());
			pstmt.setString(4, customer.getPassword());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("Failed To add Customer");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}

	}

	@Override
	public void updateCustomer(Customer customer) throws CouponsSystemException {
		// TODO Auto-generated method stub
		if (!isExists(customer.getEmail(), customer.getPassword())) {
			throw new CouponsSystemException("the customer doesn't exists");
		} else {
			Connection con = ConnectionPool.getInstance().getConnection();
			String sqlUpdateCustomers = "update customers set first_Name=?,last_Name=?,email=?,password=? where id=? ";

			try {
				PreparedStatement pstmt = con.prepareStatement(sqlUpdateCustomers);
				pstmt.setString(1, customer.getFirstName());
				pstmt.setString(2, customer.getLastName());
				pstmt.setString(3, customer.getEmail());
				pstmt.setString(4, customer.getPassword());
				pstmt.setInt(5, customer.getId());
				pstmt.executeUpdate();
			} catch (SQLException e) {

				ConnectionPool.getInstance().restoreConnection(con);
				throw new CouponsSystemException("Failed to Update Customer");
			} finally {
				ConnectionPool.getInstance().restoreConnection(con);

			}
		}
	}

	@Override
	public void deleteCustomer(int customerID) throws CouponsSystemException {

		Connection con = ConnectionPool.getInstance().getConnection();
		try {
			Customer customer = getOneCustomer(customerID);
			if (!isExists(customer.getEmail(), customer.getPassword())) {
				ConnectionPool.getInstance().restoreConnection(con);
				throw new CouponsSystemException("the customer doesn't exists");
			} else {
				String sqlDeleteCompany = "delete from Customers where id= ?";
				PreparedStatement pstmt = con.prepareStatement(sqlDeleteCompany);
				pstmt.setInt(1, customerID);
				pstmt.executeLargeUpdate();

			}
		} catch (SQLException e) {
			ConnectionPool.getInstance().restoreConnection(con);

			throw new CouponsSystemException("Failed to Delete Customer");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}
	}

	@Override
	public ArrayList<Customer> getAllCustomers() throws CouponsSystemException {
		// TODO Auto-generated method stub
		ArrayList<Customer> allCustomers = new ArrayList<Customer>();
		String sqlGetAllCustomers = "select * from customers";
		Connection con = ConnectionPool.getInstance().getConnection();

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlGetAllCustomers);

			while (rs.next()) {
				Customer customer = new Customer();
				customer.setId(rs.getInt("id"));
				customer.setFirstName(rs.getString("first_Name"));
				customer.setLastName(rs.getString("last_Name"));
				customer.setEmail(rs.getString("email"));
				customer.setPassword(rs.getString("password"));
				allCustomers.add(customer);
			}
		} catch (SQLException e) {

			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("Failed to Get All Customers");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}

		return allCustomers;

	}

	@Override
	public Customer getOneCustomer(int customerID) throws CouponsSystemException {
		// TODO Auto-generated method stub
		Connection con = ConnectionPool.getInstance().getConnection();
		Customer customer = new Customer();

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from customers where id=" + customerID);
			if (rs.equals(null)) {
				ConnectionPool.getInstance().restoreConnection(con);
				return null;
			}
			while (rs.next()) {

				customer.setId(rs.getInt("id"));
				customer.setFirstName(rs.getString("first_Name"));
				customer.setLastName(rs.getString("Last_Name"));
				customer.setEmail(rs.getString("email"));
				customer.setPassword(rs.getString("password"));

			}

		} catch (SQLException e) {

			throw new CouponsSystemException("couldn't find the customer");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}

		return customer;

	}

	public Customer getOneCustomer(String email) throws CouponsSystemException {
		// TODO Auto-generated method stub
		Connection con = ConnectionPool.getInstance().getConnection();
		Customer customer = new Customer();

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from customers where email= '" + email + "'");

			while (rs.next()) {

				customer.setId(rs.getInt("id"));
				customer.setFirstName(rs.getString("first_Name"));
				customer.setLastName(rs.getString("Last_Name"));
				customer.setEmail(rs.getString("email"));
				customer.setPassword(rs.getString("password"));

			}

		} catch (SQLException e) {

			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("Failed To get Customer By mail");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}

		return customer;

	}

}
