package com.coupons.sys.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.coupons.sys.beans.Coupon;
import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * the class CouonDBDO is a data access object that responsible to use data from
 * the tables that relate to the coupon data.
 * 
 * @author Shir
 *
 */
public class CouponDBDAO implements CouponDAO {

	public CouponDBDAO() {
		super();
	}

	@Override
	public boolean isExists(int id) throws CouponsSystemException {
		Connection con = ConnectionPool.getInstance().getConnection();
		String sqlIsExists = "select * from coupons where id=" + id;
		java.sql.Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlIsExists);
			if (rs != null) {

				ConnectionPool.getInstance().restoreConnection(con);
				return true;
			}

		} catch (SQLException e) {
			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("No Coupon Found");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}
		return false;
	}

	@Override
	public void addCoupon(Coupon coupon) throws CouponsSystemException {
		String sqlAddCoupon = "insert into coupons (company_id,Category_id,title,description,start_Date,end_Date"
				+ ",amount,price,image) values (?,?,?,?,?,?,?,?,?)";
		Connection con = ConnectionPool.getInstance().getConnection();

		try {
			PreparedStatement pstmt = con.prepareStatement(sqlAddCoupon);
			pstmt.setInt(1, coupon.getCompanyID());
			pstmt.setInt(2, (coupon.getCategory()));
			pstmt.setString(3, coupon.getTitle());
			pstmt.setString(4, coupon.getDescription());
			pstmt.setDate(5, (coupon.getStartDate()));
			pstmt.setDate(6, (coupon.getEndDate()));
			pstmt.setInt(7, coupon.getAmount());
			pstmt.setDouble(8, coupon.getPrice());
			pstmt.setString(9, coupon.getImage());
			pstmt.executeUpdate();
		} catch (SQLException e) {

			ConnectionPool.getInstance().restoreConnection(con);

			throw new CouponsSystemException("Failed to Add Coupon");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}
	}

	@Override
	public void updateCoupon(Coupon coupon) throws CouponsSystemException {
		if (isExists(coupon.getId())) {
			String sqlUpdateCoupon = "update coupons set category_id=?,title=?,description=?,start_Date=?,end_Date=?,amount=?,price=?,image=? where id=?";
			Connection con = ConnectionPool.getInstance().getConnection();
			try {
				PreparedStatement pstmt = con.prepareStatement(sqlUpdateCoupon);

				pstmt.setInt(1, (coupon.getCategory()));
				pstmt.setString(2, coupon.getTitle());
				pstmt.setString(3, coupon.getDescription());
				pstmt.setDate(4, coupon.getStartDate());
				pstmt.setDate(5, coupon.getEndDate());
				pstmt.setInt(6, coupon.getAmount());
				pstmt.setDouble(7, coupon.getPrice());
				pstmt.setString(8, coupon.getImage());
				pstmt.setInt(9, coupon.getId());

				pstmt.executeUpdate();

			} catch (SQLException e) {

				ConnectionPool.getInstance().restoreConnection(con);
				throw new CouponsSystemException("Failed to Updte Coupon");
			} finally {
				ConnectionPool.getInstance().restoreConnection(con);

			}
		}
	}

	@Override
	public void deleteCoupon(int id) throws CouponsSystemException {
		Coupon coupon = new Coupon(id);
		if (!isExists(coupon.getId())) {

			throw new CouponsSystemException("the coupon doesn't exsist");
		} else {
			Connection con = ConnectionPool.getInstance().getConnection();

			String sqlDeleteCoupon = "delete from coupons where id= " + id;
			try {
				Statement stmt = con.createStatement();
				stmt.executeUpdate(sqlDeleteCoupon);
			} catch (SQLException e) {

				ConnectionPool.getInstance().restoreConnection(con);
				throw new CouponsSystemException("Failed to delete");

			} finally {

				ConnectionPool.getInstance().restoreConnection(con);
			}

		}

	}

	@Override
	public ArrayList<Coupon> getAllCoupons() throws CouponsSystemException {
		ArrayList<Coupon> allCoupons = new ArrayList<Coupon>();
		String sqlGetAllCoupons = "select * from coupons";

		Connection con = ConnectionPool.getInstance().getConnection();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlGetAllCoupons);

			while (rs.next()) {
				Coupon coupon = new Coupon();
				coupon.setId(rs.getInt("id"));
				coupon.setCompanyID(rs.getInt("company_id"));
				coupon.setCategory(rs.getInt("category_id"));
				coupon.setTitle(rs.getString("title"));
				coupon.setDescription(rs.getString("description"));
				coupon.setStartDate((rs.getDate("start_Date")));
				coupon.setEndDate((rs.getDate("end_Date")));
				coupon.setAmount(rs.getInt("amount"));
				coupon.setPrice(rs.getDouble("price"));
				coupon.setImage(rs.getString("image"));

				allCoupons.add(coupon);
			}

		} catch (SQLException e) {

			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("Faile to get all Coupons");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);

		}
		return allCoupons;

	}

	@Override
	public Coupon getCoupon(int id) throws CouponsSystemException {
		String sqlGetCoupon = "select * from coupons where id=" + id;
		Connection con = ConnectionPool.getInstance().getConnection();
		Coupon coupon = new Coupon();

		try {
			Statement stmt = con.createStatement();
			ResultSet rs;

			rs = stmt.executeQuery(sqlGetCoupon);

			while (rs.next()) {

				coupon.setId(rs.getInt("id"));
				coupon.setCompanyID(rs.getInt("company_id"));
				coupon.setCategory(rs.getInt("category_id"));
				coupon.setTitle(rs.getString("title"));
				coupon.setDescription(rs.getString("description"));
				coupon.setStartDate((rs.getDate("start_Date")));
				coupon.setEndDate((rs.getDate("end_Date")));
				coupon.setAmount(rs.getInt("amount"));
				coupon.setPrice(rs.getDouble("price"));
				coupon.setImage(rs.getString("image"));

			}
		} catch (SQLException e) {

			ConnectionPool.getInstance().restoreConnection(con);

			throw new CouponsSystemException("the coupon doesn't found");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}

		return coupon;

	}

	public ArrayList<Coupon> getALLCouponsByCompanyId(int companyId) throws CouponsSystemException {
		Connection con = ConnectionPool.getInstance().getConnection();
		ArrayList<Coupon> allCoupons = new ArrayList<Coupon>();

		try {
			Statement stmt = con.createStatement();
			ResultSet rs;

			rs = stmt.executeQuery("select * from coupons where company_ID= " + companyId);

			while (rs.next()) {
				Coupon coupon = new Coupon();
				coupon.setId(rs.getInt("id"));
				coupon.setCompanyID(rs.getInt("company_id"));
				coupon.setCategory(rs.getInt("category_id"));
				coupon.setTitle(rs.getString("title"));
				coupon.setDescription(rs.getString("description"));
				coupon.setStartDate((rs.getDate("start_Date")));
				coupon.setEndDate((rs.getDate("end_Date")));
				coupon.setAmount(rs.getInt("amount"));
				coupon.setPrice(rs.getDouble("price"));
				coupon.setImage(rs.getString("image"));

				allCoupons.add(coupon);
			}
		} catch (SQLException e) {

			ConnectionPool.getInstance().restoreConnection(con);

			throw new CouponsSystemException("the company doesn't found");
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}

		return allCoupons;
	}

	public List<Coupon> getAllCompanyCouponsByCategory(int companyId, int categoryId) throws CouponsSystemException {

		String sql = " select * from coupons where company_id=" + companyId + " and Category_id=" + categoryId;
		return CouponGenericGetter(sql);
	}

	public List<Coupon> getAllExpiredCoupons() throws CouponsSystemException {
		List<Coupon> expierdCoupons = new ArrayList<>();

		String sql = "select * from coupons where END_DATE < current_date()";
		expierdCoupons = this.CouponGenericGetter(sql);
		return expierdCoupons;
	}

	@Override
	public List<Coupon> getAllCompanyCouponsByMaxPrice(int companyId, Double maxPrice) throws CouponsSystemException {
		String sqlGetAllCompanyCouponsByMaxPrice = "select * from coupons where company_id=" + companyId + " and Price<"
				+ maxPrice;
		return CouponGenericGetter(sqlGetAllCompanyCouponsByMaxPrice);
	}

	public List<Coupon> CouponGenericGetter(String sql) throws CouponsSystemException {
		ArrayList<Coupon> genericCoupons = new ArrayList<Coupon>();
		String sqlCommand = sql;

		Connection con = ConnectionPool.getInstance().getConnection();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlCommand);

			while (rs.next()) {
				Coupon coupon = new Coupon();

				coupon.setId(rs.getInt("id"));
				coupon.setCompanyID(rs.getInt("company_id"));
				coupon.setCategory(rs.getInt("category_id"));
				coupon.setTitle(rs.getString("title"));
				coupon.setDescription(rs.getString("description"));
				coupon.setStartDate(rs.getDate("start_Date"));
				coupon.setEndDate((rs.getDate("end_Date")));
				coupon.setAmount(rs.getInt("amount"));
				coupon.setPrice(rs.getDouble("price"));
				coupon.setImage(rs.getString("image"));

				genericCoupons.add(coupon);

			}
		}

		catch (SQLException e) {

			ConnectionPool.getInstance().restoreConnection(con);
			throw new CouponsSystemException("Faile to get all Coupons");
		} finally {

			ConnectionPool.getInstance().restoreConnection(con);
		}
		return genericCoupons;

	}

}