package com.coupons.sys.clients;

import java.util.ArrayList;
import java.util.List;

import com.coupons.sys.beans.Company;
import com.coupons.sys.beans.Coupon;
import com.coupons.sys.db.CompaniesDAO;
import com.coupons.sys.db.CompaniesDBDAO;
import com.coupons.sys.db.CouponDAO;
import com.coupons.sys.db.CouponDBDAO;
import com.coupons.sys.db.CustomerVsCouponDAO;
import com.coupons.sys.db.CustomerVsCouponDBDAO;
import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * companyFacade is a class that defined the business logic of a company client.
 * 
 * @author Shir
 *
 */
public class CompanyFacade extends ClientFacade {
	private Company company;
	private CouponDAO couponDAO = new CouponDBDAO();
	private CompaniesDAO companiesDAO = new CompaniesDBDAO();
	private CustomerVsCouponDAO customer_vs_cuoponDAO = new CustomerVsCouponDBDAO();

	public CompanyFacade() {
		super();
	}

	@Override
	public boolean login(String email, String password) {
		try {
			Boolean login = this.companiesDAO.isExists(email, password);
			this.company = this.companiesDAO.getCompany(email);

			return login;

		} catch (CouponsSystemException e) {

			new CouponsSystemException("failed to Login Wrong Mail Or Password" + email + password);

		}
		return false;

	}

	/**
	 * returns the current company that had login.
	 * 
	 * @return company
	 */
	public Company getCompany() {
		return company;
	}

	/**
	 * sets the company that had login.
	 * 
	 * @param company
	 */
	public void setCompany(Company company) {
		this.company = company;
	}

	/**
	 * add a coupon to the company.
	 * 
	 * @param newCoupon
	 * @throws CouponsSystemException
	 */
	public void addCoupon(Coupon newCoupon) throws CouponsSystemException {
		List<Coupon> allCouponsByCompId = this.couponDAO.getALLCouponsByCompanyId(newCoupon.getCompanyID());

		for (Coupon coupon : allCouponsByCompId) {
			if (coupon.getTitle().equals(newCoupon.getTitle())) {
				throw new CouponsSystemException("Failed to add Coupon with the same Title");
			}

		}
		this.couponDAO.addCoupon(newCoupon);

	}

	/**
	 * Update a coupon.
	 * 
	 * @param coupon
	 * @throws CouponsSystemException
	 */
	public void updateCoupon(Coupon coupon) throws CouponsSystemException {
		if ((this.couponDAO.isExists(coupon.getId())))

		{
			new CouponDBDAO().updateCoupon(coupon);
		} else
			throw new CouponsSystemException("Coupon Doesn't Exist or wrong company id");

	}

	/**
	 * delete a coupon from the company by coupon id.
	 * 
	 * @param couponId
	 * @throws CouponsSystemException
	 */
	public void deleteCoupon(int couponId) throws CouponsSystemException {

		this.customer_vs_cuoponDAO.deleteCoupon(couponId);

		this.couponDAO.deleteCoupon(couponId);

	}

	/**
	 * returns all the coupons of the company.
	 * 
	 * @return all coupons
	 * @throws CouponsSystemException
	 */
	public List<Coupon> getCompanyCoupons() throws CouponsSystemException {

		List<Coupon> allCoupons = new ArrayList<>();
		allCoupons = this.couponDAO.getALLCouponsByCompanyId(this.company.getId());
		return allCoupons;
	}

	/**
	 * returns all the company's coupon by category.
	 * 
	 * @param categoryId
	 * @return AllCompanyCouponsByCategory
	 * @throws CouponsSystemException
	 */
	public List<Coupon> getCompanyCoupons(int categoryId) throws CouponsSystemException {
		return this.couponDAO.getAllCompanyCouponsByCategory(this.company.getId(), categoryId);
	}

	/**
	 * returns all the company's coupons by maximum price.
	 * 
	 * @param maxPrice
	 * @return AllCompanyCouponsByMaxPrice
	 * @throws CouponsSystemException
	 */
	public List<Coupon> getCompanyCoupons(Double maxPrice) throws CouponsSystemException {
		return this.couponDAO.getAllCompanyCouponsByMaxPrice(this.company.getId(), maxPrice);
	}

	/**
	 * returns company's details.
	 * 
	 * @return company.
	 */
	public Company getCompanyDetailes() {
		return this.company;
	}
}