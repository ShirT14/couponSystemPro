package com.coupons.sys.clients;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.coupons.sys.beans.Coupon;
import com.coupons.sys.beans.Customer;
import com.coupons.sys.db.CouponDAO;
import com.coupons.sys.db.CouponDBDAO;
import com.coupons.sys.db.CustomerVsCouponDAO;
import com.coupons.sys.db.CustomerVsCouponDBDAO;
import com.coupons.sys.db.CustomersDAO;
import com.coupons.sys.db.CustomersDBDAO;
import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * CustomerFacade is a class that defined the business logic of customer client.
 * 
 * @author Shir
 *
 */
public class CustomerFacade extends ClientFacade {

	private CustomersDAO customerDAO = new CustomersDBDAO();
	private CustomerVsCouponDAO customerVsCouponDAO = new CustomerVsCouponDBDAO();
	private CouponDAO couponDAO = new CouponDBDAO();
	private Customer customer = new Customer();;

	public CustomersDAO getCustomerDAO() {
		return customerDAO;
	}

	public CustomerVsCouponDAO getCustomerVsCouponDAO() {
		return customerVsCouponDAO;
	}

	public CouponDAO getCouponDAO() {
		return couponDAO;
	}

	public CustomerFacade() {
		super();
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public boolean login(String email, String password) throws CouponsSystemException {

		boolean exists = this.customerDAO.isExists(email, password);

		this.customer = customerDAO.getOneCustomer(email);
		return exists;

	}

	/**
	 * a method that execute purchase of coupon for customer.
	 * 
	 * @param coupon
	 * @throws CouponsSystemException
	 */
	public void purchaseCoupon(Coupon coupon) throws CouponsSystemException {
		if (!this.couponDAO.isExists(coupon.getId())) {
			throw new CouponsSystemException("this coupon doen't exist");
		}
		ArrayList<Coupon> allCoupon = this.customerVsCouponDAO
				.CouponGenericGetter("select * from customers_vs_coupons where coupon_id= " + coupon.getId());
		if (!(allCoupon == null)) {
			for (Coupon coupon2 : allCoupon) {

				if (coupon.getId() == coupon2.getId()) {
					throw new CouponsSystemException("this customer already purchased this coupon");
				}
			}

		}
		if (coupon.getAmount() == 0) {
			throw new CouponsSystemException("this coupon sould out");
		}

		Date date = new Date();

		if (coupon.getEndDate().before(date)) {
			throw new CouponsSystemException("this coupon expired");
		}

		this.customerVsCouponDAO.addCustomerAndCoupon(this.customer, coupon);
		coupon.setAmount(coupon.getAmount() - 1);
		this.couponDAO.updateCoupon(coupon);

	}

	/**
	 * returns all the coupons that the customer purchased.
	 * 
	 * @return allCustomerCoupons
	 * @throws CouponsSystemException
	 */
	public ArrayList<Coupon> getAllCustomerCoupons() throws CouponsSystemException {
		ArrayList<Coupon> allCouponsId = this.customerVsCouponDAO
				.CouponGenericGetter("select * from customers_vs_coupons where customer_id= " + this.customer.getId());
		ArrayList<Coupon> allCoupons = new ArrayList<>();
		for (Coupon coupon : allCouponsId) {
			Coupon c = new Coupon();
			c = this.couponDAO.getCoupon(coupon.getId());
			allCoupons.add(c);
		}
		return allCoupons;

	}

	/**
	 * returns all customer coupon by category.
	 * 
	 * @param categoryId
	 * @return allCustomerCouponsByCategory
	 * @throws CouponsSystemException
	 */

	public List<Coupon> getAllCustomerCoupons(int categoryId) throws CouponsSystemException {

		String sql = "select * from coupons where category_Id= " + categoryId;
		List<Coupon> allCustomerCouponsByCategory = this.getAllCustomerCouponsByParameter(sql);
		return allCustomerCouponsByCategory;

	}

	/**
	 * inside method that return a list of coupon by a parameter .
	 * 
	 * @param sql
	 * @return allCustomerCouponsByParam
	 * @throws CouponsSystemException
	 */

	public List<Coupon> getAllCustomerCouponsByParameter(String sql) throws CouponsSystemException {
		List<Coupon> allCustomerCoupons;
		List<Coupon> allCouponsByParam;
		List<Coupon> allCustomerCouponsByParam = new ArrayList<>();
		try {
			allCustomerCoupons = this.getAllCustomerCoupons();
			allCouponsByParam = this.couponDAO.CouponGenericGetter(sql);
			for (Coupon ParamCoupon2 : allCouponsByParam) {
				for (Coupon customerCoupon : allCustomerCoupons) {

					if ((customerCoupon.getId()) == (ParamCoupon2.getId())) {

						allCustomerCouponsByParam.add(this.couponDAO.getCoupon(ParamCoupon2.getId()));
					}
				}
			}

		} catch (CouponsSystemException e) {

			throw new CouponsSystemException("the system couldn't return the list");
		}

		return allCustomerCouponsByParam;
	}

	/**
	 * return all coupons by maximum price
	 * 
	 * @param maxPrice
	 * @return allCustomerCouponsByMaxPrice
	 * @throws CouponsSystemException
	 */

	public List<Coupon> getAllCoupon(double maxPrice) throws CouponsSystemException {

		String sql = "select * from coupons where price < " + maxPrice;

		List<Coupon> allCustomerCouponsByMaxPrice = this.getAllCustomerCouponsByParameter(sql);

		return allCustomerCouponsByMaxPrice;
	}

	/**
	 * returns the current customer with his details.
	 * 
	 * @return
	 * @throws CouponsSystemException
	 */
	public Customer getCustomer() throws CouponsSystemException {
		Customer customer = this.customerDAO.getOneCustomer(this.customer.getId());
		return customer;
	}
}
