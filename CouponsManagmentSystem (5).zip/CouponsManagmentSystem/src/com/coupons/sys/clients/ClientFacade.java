package com.coupons.sys.clients;

import com.coupons.sys.db.CompaniesDAO;
import com.coupons.sys.db.CompaniesDBDAO;
import com.coupons.sys.db.CouponDAO;
import com.coupons.sys.db.CouponDBDAO;
import com.coupons.sys.db.CustomerVsCouponDAO;
import com.coupons.sys.db.CustomerVsCouponDBDAO;
import com.coupons.sys.db.CustomersDAO;
import com.coupons.sys.db.CustomersDBDAO;
import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * the super class of all the clients facades.
 * 
 * @author Shir
 *
 */
public abstract class ClientFacade {

	private CompaniesDAO companyDAO = new CompaniesDBDAO();
	private CustomersDAO customersDAO = new CustomersDBDAO();
	private CouponDAO couponDAO = new CouponDBDAO();
	private CustomerVsCouponDAO customerVsCouponDAO = new CustomerVsCouponDBDAO();

	public CustomerVsCouponDAO getCustomerVsCouponDAO() {
		return customerVsCouponDAO;
	}

	public CompaniesDAO getCompanyDAO() {
		return companyDAO;
	}

	public CustomersDAO getCustomersDAO() {
		return customersDAO;
	}

	public CouponDAO getCouponDAO() {
		return couponDAO;
	}

	public ClientFacade() {
		super();

	}

	/**
	 * 
	 * @param email
	 * @param password
	 * @return true/false
	 * @throws CouponsSystemException
	 */
	public abstract boolean login(String email, String password) throws CouponsSystemException;

}
