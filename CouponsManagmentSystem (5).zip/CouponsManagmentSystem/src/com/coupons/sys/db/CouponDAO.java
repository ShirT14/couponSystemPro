package com.coupons.sys.db;

import java.util.ArrayList;
import java.util.List;

import com.coupons.sys.beans.Coupon;
import com.coupons.sys.exeptions.CouponsSystemException;

/**
 * an interface that allows to make change in coupons table.
 * 
 * @author Shir
 *
 */
public interface CouponDAO {
	/**
	 * the method isExist check if the coupon is exists in the database according to
	 * the email and the coupon's id number.
	 * 
	 * @param id
	 * @return true/ false
	 * @throws CouponsSystemException
	 */
	public boolean isExists(int id) throws CouponsSystemException;

	/**
	 * addCoupon is a method that allows to add a coupon to the database.
	 * 
	 * @param coupon
	 * @throws CouponsSystemException
	 */

	public void addCoupon(Coupon coupon) throws CouponsSystemException;

	/**
	 * update a coupon in the database.
	 * 
	 * @param Coupon
	 * @throws CouponsSystemException
	 */
	public void updateCoupon(Coupon Coupon) throws CouponsSystemException;

	/**
	 * deleteCoupon is a method that allows to delete a coupon according a coupon's
	 * id number.
	 * 
	 * @param id
	 * @throws CouponsSystemException
	 */
	public void deleteCoupon(int id) throws CouponsSystemException;

	/**
	 * getAllCoupon is a method that can be use to get all the coupons from the
	 * database. the method gets no parameters.
	 * 
	 * @return allCoupons
	 * @throws CouponsSystemException
	 */
	public ArrayList<Coupon> getAllCoupons() throws CouponsSystemException;

	/**
	 * the method getCooupon allows to get specified coupon according to a coupon's
	 * id number.
	 * 
	 * @param CouponId
	 * @return coupon
	 * @throws CouponsSystemException
	 */
	public Coupon getCoupon(int CouponId) throws CouponsSystemException;

	/**
	 * a method that return all the coupons according to companies id
	 * 
	 * @param companyId
	 * @return allCouponsByCompanyId
	 * @throws CouponsSystemException
	 */
	public ArrayList<Coupon> getALLCouponsByCompanyId(int companyId) throws CouponsSystemException;

	/**
	 * a method that returns all the coupons from the database under a max price
	 * according to a company id.
	 * 
	 * @param companyId
	 * @param price
	 * @return allCompanyCouponsByMaxPrice
	 * @throws CouponsSystemException
	 */

	public List<Coupon> getAllCompanyCouponsByMaxPrice(int companyId, Double price) throws CouponsSystemException;

	/**
	 * a method that returns all the coupons in the database according to a
	 * company's id and a category.
	 * 
	 * @param companyId
	 * @param categoryId
	 * @return allCompanyCouponsByCategory
	 * @throws CouponsSystemException
	 */
	List<Coupon> getAllCompanyCouponsByCategory(int companyId, int categoryId) throws CouponsSystemException;

	/**
	 * a generic method that get a sql commend and return a list of coupons.
	 * 
	 * @param sql
	 * @return list of coupons
	 * @throws CouponsSystemException
	 */
	public List<Coupon> CouponGenericGetter(String sql) throws CouponsSystemException;

	/**
	 * returns all the coupon that expired;
	 * 
	 * @return
	 */
	public List<Coupon> getAllExpiredCoupons() throws CouponsSystemException;
}
