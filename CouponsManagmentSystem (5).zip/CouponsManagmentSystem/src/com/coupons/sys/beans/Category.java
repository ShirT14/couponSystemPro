package com.coupons.sys.beans;

public enum Category {
	FOOD, ELECTRICITY, RESTAURANT, VACATION;

}
